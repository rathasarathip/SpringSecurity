package com.siemens.rtls.config.jwt;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
class JwtConfiguration {
    @Value("${jwt.token.header}")
    public String tokenHeader;

    @Value("${jwt.key}")
    public String secretkey;

    @Value("${jwt.token.expiry}")
    public Long tokenExpiry;
}
