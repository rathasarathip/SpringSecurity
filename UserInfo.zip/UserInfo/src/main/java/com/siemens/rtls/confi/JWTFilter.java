package com.siemens.rtls.confi;

import com.siemens.rtls.config.model.ClaimsTemplate;
import com.siemens.rtls.config.model.SessionUser;
import com.siemens.rtls.service.EncoderService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Component
public class JWTFilter extends GenericFilterBean {
	private static final Log log = LogFactory.getLog(JWTFilter.class);
	private static final String AUTHORIZATION_HEADER = "Authorization";
	private final EncoderService encoderService;
	@Value("${jwt.key}")
	private String secretkey;

	@Value("${jwt.token.header}")
	private String tokenHeader;

	public JWTFilter(EncoderService encoderService) {
		this.encoderService = encoderService;
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		setRequestInfoforMDC(request);
		setAccessControllHeaders(response);

		final String requestURL = String.valueOf(request.getRequestURL());
		final String requestMethod = request.getMethod();

		if ("OPTIONS".equalsIgnoreCase(requestMethod)) {
			response.setStatus(HttpServletResponse.SC_OK);
		} else if ((requestURL.contains("/user/authenticate") && requestMethod.equalsIgnoreCase("POST"))) {

			filterChain.doFilter(servletRequest, servletResponse);

		} else {
			String authHeader = request.getHeader(AUTHORIZATION_HEADER);
			if (authHeader == null || authHeader.isEmpty()) {
				authHeader = request.getHeader("Token");
			}
			if (authHeader == null || !authHeader.startsWith(tokenHeader)) {
				((HttpServletResponse) servletResponse).sendError(HttpServletResponse.SC_UNAUTHORIZED,
						"invalid authorization token.");
			} else {
				try {
					final String token = authHeader.substring(7);
					final Claims claims = Jwts.parser().setSigningKey(secretkey).parseClaimsJws(token).getBody();

					final String userName = (String) claims.get(ClaimsTemplate.USER_NAME);
					final String role = (String) claims.get(ClaimsTemplate.ROLE);

					MDC.put("userName", userName);

					SecurityContextHolder.getContext().setAuthentication(getAuthentication(userName, role));
					filterChain.doFilter(servletRequest, servletResponse);

				} catch (ExpiredJwtException e) {
					log.error("token expired", e);
					((HttpServletResponse) servletResponse).sendError(HttpServletResponse.SC_UNAUTHORIZED,
							"expired token");
				} catch (Exception e) {
					log.error("invalid token", e);
					((HttpServletResponse) servletResponse).sendError(HttpServletResponse.SC_UNAUTHORIZED,
							"invalid token");
				}
			}
		}
	}

	private void setRequestInfoforMDC(HttpServletRequest request) {
		String url = request.getRequestURL().toString();
		String queryString = request.getQueryString();
		String method = request.getMethod();

		HttpSession session = request.getSession();
		if (session != null) {
			MDC.put("url", url + ((queryString == null) ? "" : "?" + queryString));
			MDC.put("method", method);
			MDC.put("sessionID", session.getId());
		}
	}

	private void setAccessControllHeaders(HttpServletResponse response) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Credentials", "true");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, PUT,OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, tenant-id");
	}

	private Authentication getAuthentication(String userName, String role) {
		List<SimpleGrantedAuthority> authorities = new ArrayList<>(
				Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role)));
		SessionUser user = new SessionUser(userName, "", true, true, true, true, authorities, userName, role);
		return new UsernamePasswordAuthenticationToken(user, "", authorities);
	}
}
