package com.siemens.rtls.config.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Component;

@Component
public class JwtDecoder {
    private final JwtConfiguration jwtConfiguration;

    public JwtDecoder(JwtConfiguration jwtConfiguration) {
        this.jwtConfiguration = jwtConfiguration;
    }

    public Claims decode(String token) throws Exception {
        return Jwts.parser().setSigningKey(jwtConfiguration.secretkey).parseClaimsJws(token).getBody();
    }
}
