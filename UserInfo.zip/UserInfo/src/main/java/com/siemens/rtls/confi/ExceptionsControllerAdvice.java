package com.siemens.rtls.confi;

import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import com.siemens.rtls.model.RestResponse;

@ControllerAdvice(annotations = { RestController.class })
public class ExceptionsControllerAdvice {
	private static final Log logger = LogFactory.getLog(ExceptionsControllerAdvice.class);

	// Handling Object validation errors
	@ExceptionHandler({ MethodArgumentNotValidException.class })
	public ResponseEntity<RestResponse> handleBindingErrors(MethodArgumentNotValidException ex) {
		String errorMsg = ex.getBindingResult().getFieldErrors().stream()
				.map(DefaultMessageSourceResolvable::getDefaultMessage).findFirst().orElse(ex.getMessage());
		RestResponse response = new RestResponse();
		response.setCode(501);
		response.setStatus(false);
		response.setMsg(errorMsg);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// Handling remaining errors
	@ExceptionHandler({ RuntimeException.class })
	public ResponseEntity<RestResponse> handleRuntimeException(RuntimeException ex) {
		RestResponse response = new RestResponse();
		response.setCode(505);
		response.setStatus(false);
		response.setMsg(ex.getMessage());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// Handling Request body errors
	@ExceptionHandler({ HttpMessageNotReadableException.class, HttpMediaTypeNotSupportedException.class })
	public ResponseEntity<RestResponse> handleRequestErrors(Exception ex) {
		RestResponse response = new RestResponse();
		response.setCode(504);
		response.setStatus(false);
		if (ex instanceof HttpMediaTypeNotSupportedException) {
			response.setMsg("content type not supported");
		} else {
			response.setMsg("Request body is not valid");
		}
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// Handling global errors
	@ExceptionHandler({ Exception.class })
	public ResponseEntity<RestResponse> handleGlobalErrors(Exception ex) {
		logger.error(ex.getMessage(), ex);

		RestResponse response = new RestResponse();
		response.setCode(502);
		response.setStatus(false);
		response.setMsg(ex.getMessage());
		response.setData(ex.getCause());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}