package com.siemens.rtls.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.siemens.rtls.config.model.ClaimsTemplate;
import com.siemens.rtls.config.model.Token;
import com.siemens.rtls.model.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class AuthenticationService {

	@Value("${jwt.token.header}")
	private String tokenHeader;

	@Value("${jwt.key}")
	private String secretkey;

	@Value("${jwt.token.expiry}")
	private Long tokenExpiry;

	public Token getTokenForUser(User user) {
		try {
			Date issuedDate = new Date();
			Date expirationTime = new Date(issuedDate.getTime() + tokenExpiry);

			String tokenString = Jwts.builder().claim(ClaimsTemplate.USER_NAME, user.getUserName())
					.claim(ClaimsTemplate.ROLE, user.getRole().toUpperCase()).setIssuedAt(issuedDate)
					.setExpiration(expirationTime).signWith(SignatureAlgorithm.HS256, secretkey).compact();

			final Token token = new Token();
			//token.setUserId(user.getId());
			token.setUserName(user.getUserName());
			//token.setRole(user.getRole());

			token.setToken(tokenHeader + tokenString);
			return token;
		} catch (Exception e) {
			throw new RuntimeException("error while generating token");
		}
	}
}
