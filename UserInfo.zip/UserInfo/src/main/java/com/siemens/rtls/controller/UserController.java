package com.siemens.rtls.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.siemens.rtls.model.RestResponse;
import com.siemens.rtls.model.User;
import com.siemens.rtls.service.EncoderService;
import com.siemens.rtls.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	private final UserService userService;
	private final EncoderService encoderService;

	@Autowired
	public UserController(UserService userService, EncoderService encoderService) {
		this.userService = userService;
		this.encoderService = encoderService;
	}

	@Value("${user.roles}")
	private String[] userRoles;

	@PostMapping("/add")
	//@PreAuthorize("hasAnyRole('ROLE_ADMIN')")
	public RestResponse addUser(@RequestBody User user) {
		RestResponse response = new RestResponse();
		user.setUserName(user.getUserName().toLowerCase());
		user.setPassword(encoderService.encode(user.getPassword()));
		userService.AddUserInfo(user);
		response.setMsg("user created successfully");
		HashMap<String, Object> map = new HashMap<>();
		map.put("id", user.getId());
		response.setData(map);
		return response;
	}

	@GetMapping("/list")
	public List<User> getAll() {
		return userService.getAllusers();
	}

	@GetMapping("/{id}")
	public ResponseEntity<User> getUser(@PathVariable long id) {
		User user = userService.findBySpecificUser(id);
		if (user != null) {
			return new ResponseEntity<>(user, HttpStatus.OK);
		} else {
			throw new RuntimeException("user not found");

		}
	}

}
