package com.siemens.rtls.controller;

import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.siemens.rtls.config.model.Token;
import com.siemens.rtls.model.AuthenticationRequest;
import com.siemens.rtls.model.User;
import com.siemens.rtls.service.AuthenticationService;
import com.siemens.rtls.service.UserService;

@RestController
@RequestMapping("user/authenticate")
public class AuthenticationController {
	private static final Log logger = LogFactory.getLog(AuthenticationController.class);

	private final UserService userService;
	private final AuthenticationService authenticationService;

	@Autowired
	public AuthenticationController(AuthenticationService authenticationService, UserService userService) {
		this.authenticationService = authenticationService;
		this.userService = userService;
	}

	@PostMapping
	public ResponseEntity authenticateUser(@RequestBody AuthenticationRequest request) {

		User user = userService.findUserByUserNameAndPassword(request.getUserName(),
				request.getPassword());

		if (user != null) {
			Token token = authenticationService.getTokenForUser(user);
			return new ResponseEntity<>(token, HttpStatus.OK);

		} else {
			logger.info("invalid user credentials");
			throw new RuntimeException("invalid user credentials");
		}
	}
}