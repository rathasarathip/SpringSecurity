package com.siemens.rtls.model;
public class RestResponse {
    private String msg = "ok";
    private Integer code = 200;
    private boolean status = true;
    private Object data;

    public RestResponse() {
    }

    public RestResponse(Object data) {
        this.data = data;
    }

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

}
