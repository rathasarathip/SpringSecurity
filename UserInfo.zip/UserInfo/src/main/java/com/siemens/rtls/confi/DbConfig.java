package com.siemens.rtls.confi;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.siemens.rtls.model.User;
import com.siemens.rtls.repository.UserRepository;
import com.siemens.rtls.service.EncoderService;

@Component
public class DbConfig {

	private final UserRepository userRepository;

	@Autowired
	public DbConfig(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@PostConstruct
	public void init() {
		List<User> listUsers = userRepository.findAll();
		if (listUsers.isEmpty() && listUsers.size() == 0) {
			User user = new User();
			user.setFirstName("admin");
			user.setUserName("admin");
			user.setPassword("admin");
			user.setRole("ADMIN");
			user.setPhoneNumber("9912997923");
			user.setLastName("admin");
			user.setEmail("admin@gmail.com");
			userRepository.save(user);
			System.out.println("=> created new  admin profile.");
		} else {
			System.out.println("=>  admin profile found.");
		}
	}
}