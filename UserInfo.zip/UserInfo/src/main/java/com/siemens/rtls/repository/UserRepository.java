package com.siemens.rtls.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.siemens.rtls.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	User findByUserNameIgnoreCase(String userName);

	User findByUserNameAndPassword(String userName, String password);

	List<User> findByRole(String role);

}
