package com.siemens.rtls.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.siemens.rtls.model.User;
import com.siemens.rtls.repository.UserRepository;

@Service
public class UserServiceImp implements UserService {

	private final UserRepository userRepository;
	private final EncoderService encoderService;

	@Autowired
	public UserServiceImp(UserRepository userRepository, EncoderService encoderService) {
		this.userRepository = userRepository;
		this.encoderService = encoderService;
	}

	public void AddUserInfo(User user) {
		userRepository.save(user);
	}

	@Override
	public List<User> getAllusers() {

		return userRepository.findAll();
	}

	@Override
	public User findBySpecificUser(long id) {
		return userRepository.getOne(id);
	}

	@Override
	public User updateBySpecificUser(User user, long id) {
		user.setId(id);
		return userRepository.save(user);
	}

	@Override
	public User findUserByUserNameAndPassword(String name, String password) {
		password = encoderService.encode(password);
		return userRepository.findByUserNameAndPassword(name, password);
	}

	@Override
	public User getUserByUserName(String name) {
		return userRepository.findByUserNameIgnoreCase(name);
	}

}
