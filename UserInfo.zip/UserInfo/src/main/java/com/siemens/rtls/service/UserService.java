package com.siemens.rtls.service;

import java.util.List;

import com.siemens.rtls.model.User;

public interface UserService {
	void AddUserInfo(User user);

	User getUserByUserName(String name);

	List<User> getAllusers();

	User findBySpecificUser(long id);

	User updateBySpecificUser(User user, long id);

	User findUserByUserNameAndPassword(String name, String password);

}
