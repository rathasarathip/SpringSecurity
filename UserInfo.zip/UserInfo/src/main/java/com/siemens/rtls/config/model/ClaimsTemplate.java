package com.siemens.rtls.config.model;

public class ClaimsTemplate {
    public static final String USER_NAME = "u";
    public static final String ROLE = "r";
    //public static final String USER_ID = "ui";
}
