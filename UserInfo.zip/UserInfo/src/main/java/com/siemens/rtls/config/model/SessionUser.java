package com.siemens.rtls.config.model;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.Collection;

public class SessionUser extends User {
	private static final long serialVersionUID = -3531439484732724601L;

	// private final long userId;
	private final String userName;
	private final String role;

	public SessionUser(String username, String password, boolean enabled, boolean accountNonExpired,
			boolean credentialsNonExpired, boolean accountNonLocked, Collection<? extends GrantedAuthority> authorities,
			String userName, String role) {

		super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);

		// this.userId = userId;
		this.userName = userName;
		this.role = role;
	}

	public String getUserName() {
		return userName;
	}

	public String getRole() {
		return role;
	}

	@Override
	public String toString() {
		return "SessionUser [ userName=" + userName + ", role=" + role + "]";
	}

}
