package com.siemens.rtls.config.jwt;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.siemens.rtls.config.model.ClaimsTemplate;
import com.siemens.rtls.model.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtEncoder {
	private final JwtConfiguration jwtConfiguration;

	public JwtEncoder(JwtConfiguration jwtConfiguration) {
		this.jwtConfiguration = jwtConfiguration;
	}

	public String encode(User user) {
		final Date issuedDate = new Date();
		final Date expirationTime = new Date(issuedDate.getTime() + jwtConfiguration.tokenExpiry);
		String tokenString = Jwts.builder().claim(ClaimsTemplate.USER_NAME, user.getUserName())
				.claim(ClaimsTemplate.ROLE, user.getRole().toUpperCase())
				.setIssuedAt(issuedDate).setExpiration(expirationTime)
				.signWith(SignatureAlgorithm.HS256, jwtConfiguration.secretkey).compact();
		return jwtConfiguration.tokenHeader + tokenString;
	}
}
